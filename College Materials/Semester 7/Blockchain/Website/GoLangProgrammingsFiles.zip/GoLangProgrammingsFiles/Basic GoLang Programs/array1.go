package main


import (
	"fmt"
	//"math"
)

func main(){
	fmt.Println(" from Array 1 ")
	
	var a[5] int 
	fmt.Println(" from Array", a)
	
	a[2] = 2
	fmt.Println(" from Array", a)
	
	fmt.Println(" Lenght of Array", len(a))
}

Output:

from Array 1 
 from Array [0 0 0 0 0]
 from Array [0 0 2 0 0]
 Lenght of Array 5

Program exited.