package main


//Channels are the pipes that connect concurrent goroutines.
//You can send values into channels from one goroutine and receive those values into another goroutine.


import (  
    "fmt"
    "time"
)


func server1(ch chan string) {  
    time.Sleep(6 * time.Second)

//The <-channel syntax receives a value from the channel. 

    ch <- "from server1"
}
func server2(ch chan string) {  
    time.Sleep(10 * time.Second)

//The <-channel syntax receives a value from the channel. 
    ch <- "from server2"

}
func main() {  
    output1 := make(chan string)
    output2 := make(chan string)
    go server1(output1)
    go server2(output2)
// Server 1 sleeps 6 seconds and Server 2 sleeps for 10 seconds
    select {
    case s1 := <-output1:
        fmt.Println(s1)
    case s2 := <-output2:
        fmt.Println(s2)
    }
}



Output:

from server1

Program exited.