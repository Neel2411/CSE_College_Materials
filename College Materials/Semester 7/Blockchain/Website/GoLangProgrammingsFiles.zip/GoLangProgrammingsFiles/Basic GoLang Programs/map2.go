package main


import 	(
	"fmt"
	)
	
	func main() {
		fmt.Println(" --- ONE --- ")
		
		//create a map
		//variable + assign a variable
		//Map to hold empID as key.
		//Map to hold empSal as value.
			
		//variable declaration
		var empSalary  map[int] int
		
		if empSalary == nil {
			
			empSalary = make (map[int]int)
			
			empSalary[10]= 5000
			empSalary[11]= 5001
			empSalary[12]= 6000
			empSalary[13]= 6001
			empSalary[14]= 7000
			empSalary[15]= 7001
		
			fmt.Println(empSalary)
			
			
			//loop through the empSalary
			for key, value := range empSalary {
				fmt.Printf("empSalary[%d] = %d\n", key, value)
			}
			fmt.Printf (" length of Map  %d", len(empSalary)	)
			
			//delete a key from a map.
			delete(empSalary,10)
			delete(empSalary,11)
			
			fmt.Println(" After delete ")
			//loop through the empSalary
			for key, value := range empSalary {
				fmt.Printf("empSalary[%d] = %d\n", key, value)
			}
			fmt.Printf (" length of Map %d\t  %d", len(empSalary), 	len(empSalary) %2)
			
			
		}
		
		
	}



Output:


 --- ONE --- 
map[10:5000 11:5001 12:6000 13:6001 14:7000 15:7001]
empSalary[11] = 5001
empSalary[12] = 6000
empSalary[13] = 6001
empSalary[14] = 7000
empSalary[15] = 7001
empSalary[10] = 5000
 length of Map  6 After delete 
empSalary[15] = 7001
empSalary[12] = 6000
empSalary[13] = 6001
empSalary[14] = 7000
 length of Map 4	  0
Program exited.