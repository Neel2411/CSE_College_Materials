package main




import 	(
	"fmt"
	)
	
	func main() {
		fmt.Println(" --- ONE --- ")
		
		//create a map
		//variable + assign a variable
		//Map to hold empID as key.
		//Map to hold empSal as value.
			
		//variable declaration
		var empSalary  map[int] int
		
		if empSalary == nil {
			
			empSalary = make (map[int]int)
			
			empSalary[10]= 5000
			empSalary[11]= 5001
			empSalary[12]= 6000
			empSalary[13]= 6001
			empSalary[14]= 7000
			empSalary[15]= 7001
		
			fmt.Println(empSalary)
			
		}
		
		//declare second map.
		var newEmpSal map[int]int
		
		newEmpSal = empSalary
		fmt.Println(newEmpSal)
		
		//make changes to newEmpSal.
		
		newEmpSal[11] = 200
		fmt.Println(empSalary)
		
	}


Output:

--- ONE --- 
map[10:5000 11:5001 12:6000 13:6001 14:7000 15:7001]
map[10:5000 11:5001 12:6000 13:6001 14:7000 15:7001]
map[10:5000 11:200 12:6000 13:6001 14:7000 15:7001]

Program exited.