package main

import (
	"fmt"
)

func main() {
	fmt.Println("	Println ")
	var a chan int
	
	if a == nil {
		fmt.Println(" Channel is null ")
		a = make (chan int)
		fmt.Printf("%T", a)
		fmt.Println("")
		fmt.Printf(" Type of a is %T", a)
	}
}


Output:

	Println 
 Channel is null 
chan int
 Type of a is chan int
Program exited.