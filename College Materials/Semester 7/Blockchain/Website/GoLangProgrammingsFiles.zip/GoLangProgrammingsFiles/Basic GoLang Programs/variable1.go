package main

//This program explain variables and declarations
import (
	"fmt"
	"math"
	"unsafe"
)

func main() {

	fmt.Println("**************************")
	fmt.Println("Hello World")
	//variable declaration
	var age int
	//variable after declaration wil have a default value
	fmt.Println("My age before declaration is", age)
	//This statement assigns age as 43
	age = 43
	fmt.Println("My age after declaration is", age)
	
	
	fmt.Println("**************************")
	//variabls can be declared in a block as below for.

	var (
		name   = "Rasmi"
		newage = 36
		height = 64
	)
	fmt.Println("Printing after block declaration")
	fmt.Println("Name is", name, "age is", newage, " height is", height)
	

	fmt.Println("**************************")
	//variable type need not be given when we use :=
	a, b := 20.0, 10.0
	var c = math.Min(a, b)
	fmt.Println("Value of a", a)
	fmt.Println("Value of b", b)
	fmt.Println("Value of math.Min(a, b)= ", c)

	fmt.Println("**************************")

	name1 := "Ram"
	name2 := "Seetha"

	fmt.Println("Name is ", name1, ", ", name2)
	//+ symbol is used to concatindate strings
	couple := name1 + " " + name2
	fmt.Println("couple is: ", couple)

	fmt.Println("**************************")
	b1 := true
	b2 := false

	fmt.Println("b1 = ", b1, " b2 = ", b2)

	//&& symbol is used to do "AND" Operation between two boolean values
	c1 := b1 && b2

	// || symbol is used to do "OR" Operation between two boolean values
	d1 := b1 || b2
	fmt.Println("Output for b1 && b2", c1, "Output for b1 || b2", d1)

	//type and size of c
	//type and size of d

	fmt.Printf("Type of c1 is %T, size of c is %d", c1, unsafe.Sizeof(c1))

	fmt.Println("\n**************************")

	const _name = "Blockchain"
	fmt.Println("Output from _name:", _name)
	//fmt.Printf("Type of _Name is: %T", _name, "Size of _name is:", unsafe.Sizeof(_name))

	fmt.Printf("Type of Name is %T, size of name is %d", _name, unsafe.Sizeof(_name))
	fmt.Println("\n**************************")
}






**************************
Hello World
My age before declaration is 0
My age after declaration is 43
**************************
Printing after block declaration
Name is Rasmi age is 36  height is 64
**************************
Value of a 20
Value of b 10
Value of C= math.Min(a, b)=  10
**************************
Name is  Ram ,  Seetha
couple is:  Ram Seetha
**************************
b1 =  true  b2 =  false
Output for b1 && b2 false Output for b1 || b2 true
Type of c1 is bool, size of c is 1
**************************
Output from _name: Blockchain
Type of Name is string, size of name is 8
**************************

Program exited.