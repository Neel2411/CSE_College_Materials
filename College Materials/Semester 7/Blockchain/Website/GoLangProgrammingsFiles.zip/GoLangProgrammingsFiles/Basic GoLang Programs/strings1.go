package main

import (  
    "fmt"
)

//rune is a data type in gloang. The rune type is an alias for int32

func mutate(s []rune) string {  

//s[0] = 'a' over writes 'a' with whatever be the value already stored in s[0].
    s[0] = 'B' 
    return string(s)
}


func main() {  
    h := "hello"
//+ symbol is used to attach two strings.

	h = h + "World"
	fmt.Println(h)
    	fmt.Println(mutate([]rune (h)))
}



Output:

helloWorld
BelloWorld

Program exited.