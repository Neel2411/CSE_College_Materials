package main

import 	(
	"fmt"
	//"time"
	)
	
func calcSquares(number int, squareop chan int) {  
    sum := 0
    for number != 0 {
        digit := number % 10
        sum += digit * digit
        number /= 10
    }
    squareop <- sum
}

func calcCubes(number int, cubeop chan int) {  
    sum := 0 
    for number != 0 {
        digit := number % 10
        sum += digit * digit * digit
        number /= 10
    }
    cubeop <- sum
} 

func main() {  
    number := 589
    sqrch := make(chan int)
    cubech := make(chan int)
    go calcSquares(number, sqrch)
    go calcCubes(number, cubech)


    squares, cubes := <-sqrch, <-cubech

fmt.Println("Final output squares", squares)
fmt.Println("Final output cubess", cubes)

    fmt.Println("Final output", squares + cubes)
}




Output:

Final output squares 170
Final output cubess 1366
Final output 1536

Program exited.