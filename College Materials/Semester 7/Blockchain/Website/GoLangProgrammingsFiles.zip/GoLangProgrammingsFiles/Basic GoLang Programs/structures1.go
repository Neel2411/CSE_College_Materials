package main


import (
		"fmt"
	//	"math"
	//	"unsafe"
	)

	
	type school struct {
		name		string
		locality	string
		board		string
		strength	int
	}

func main() { 
	fmt.Println(" From structrures")
	
	 littleElly := school {"LE", "VBL","NA",200}
	 anotherElly := school {"AE", "JPN", "NA", 300}
	 
	 fmt.Println(" LE:", littleElly)
	 fmt.Println(" AE:", anotherElly)
	
	//Structure element(variable) can be changed by referring structurename.variablename
	
	 anotherElly.board = "CBSE"
	 fmt.Println(" AE:", anotherElly)
}



Output:

From structrures
 LE: {LE VBL NA 200}
 AE: {AE JPN NA 300}
 AE: {AE JPN CBSE 300}

Program exited.