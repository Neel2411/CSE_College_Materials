package main




import 	(
	"fmt"
	)
	
	func main() {
		fmt.Println(" --- ONE --- ")
		
		//create a map
		//variable + assign a variable
		//Map to hold empID as key.
		//Map to hold empSal as value.
			
		//variable declaration
		var empSalary  map[int] int
		
		if empSalary == nil {
			fmt.Println(" -- empSalary is NULL -- ")
			fmt.Println(empSalary)
			
			empSalary = make (map[int]int)
			fmt.Println(" after make")
			fmt.Println(empSalary)
			
			empSalary[10]= 5000
			empSalary[11]= 5001
			
			fmt.Println(" after making two entries")
			fmt.Println(empSalary)
			
			//test can I add 200 for each entry.
			empSalary[10] = empSalary[10] + 5000
			
			fmt.Println(" after making salary Addition ")
			fmt.Println(empSalary)
		}
		
		
	}


Output:

--- ONE --- 
 -- empSalary is NULL -- 
map[]
 after make
map[]
 after making two entries
map[10:5000 11:5001]
 after making salary Addition 
map[10:10000 11:5001]

Program exited.