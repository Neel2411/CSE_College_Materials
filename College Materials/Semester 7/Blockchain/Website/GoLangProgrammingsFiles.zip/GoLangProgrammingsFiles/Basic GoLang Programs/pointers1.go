package main

//This program demonstrates pointers and Map structure of golang

import (
	"fmt"
)

func main() {

	fmt.Println("*****************************")

	//var a is an integer
	var a int
	a = 5

	//var b is a pointer which can hold the address of an integer
	//*int indicates the address of integer
	var b *int
	//var b holds the address of a
	b = &a
	fmt.Println("Value of the variable b (address)-", b)

	//*b indicates the content of the "address b"
	fmt.Println("Conent of the address b: ", *b)

	//changing the value of a using pointer.
	//Content of b = content of b + 10

	*b = *b + 10

	//Address of b is printed
	fmt.Println("After operation *b = *b + 10")
	fmt.Println("Value of the variable b (address)", b)

	//*b indicates the content of the "address b"
	fmt.Println("Conent of the address b: ", *b)
	//We can check that vaalue of a also got changed since we changed the content of its address

	fmt.Println("Value of a after changing the content of the pointer", a)

	fmt.Println("*****************************")

	var empSalary map[int]int

	//empSalary is the map
	empSalary = make(map[int]int)

	//index 10 and 11 are assinged the values of 5000 and 5001
	empSalary[10] = 5000
	empSalary[11] = 5001
	//Content of the Map can be printed using Println statement
	fmt.Println(empSalary)

	//empNew is a pointer to map[int]int
	var empNew *map[int]int

	//empNew holds the address of empSalary
	empNew = &empSalary
	fmt.Println("After new empNew is addressed ")

	//empNew is the address
	fmt.Println(empNew)

	//Content of empNew (which is the  empSalary)
	fmt.Println(*empNew)
	fmt.Println("*****************************")

	//Length of Content of empNew: indicates how many map contents

	fmt.Println("Len of empNew")
	fmt.Println(len(*empNew))
	fmt.Println("*****************************")

	for key, value := range *empNew {
		fmt.Printf("empNew[%d] = %d \n", key, value)
	}
	fmt.Println("*****************************")

}




*****************************
Value of the variable b (address)- 0x40e020
Conent of the address b:  5
After operation *b = *b + 10
Value of the variable b (address) 0x40e020
Conent of the address b:  15
Value of a after changing the content of the pointer 15
*****************************
map[10:5000 11:5001]
After new empNew is addressed 
&map[10:5000 11:5001]
map[10:5000 11:5001]
*****************************
Len of empNew
2
*****************************
empNew[10] = 5000 
empNew[11] = 5001 
*****************************

Program exited.