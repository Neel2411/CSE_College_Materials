package main

import (  
    "fmt"
    "math/rand"
    "sync"
    "time"
)

type Job struct {  
    id       int
    randomno int
}
type Result struct {  
    job         Job
    sumofdigits int
}

var jobs = make(chan Job, 10)  
var results = make(chan Result, 10)

func digits(number int) int {  
    sum := 0
    no := number
    for no != 0 {
        digit := no % 10
        sum += digit
        no /= 10
    }
    time.Sleep(2 * time.Second)
    return sum
}
func worker(wg *sync.WaitGroup) {  
    for job := range jobs {
        output := Result{job, digits(job.randomno)}
        results <- output
    }
    wg.Done()
}
func createWorkerPool(noOfWorkers int) {  
    var wg sync.WaitGroup
    for i := 0; i < noOfWorkers; i++ {
        wg.Add(1)
        go worker(&wg)
    }
    wg.Wait()
    close(results)
}
func allocate(noOfJobs int) {  
    for i := 0; i < noOfJobs; i++ {
        randomno := rand.Intn(999)
        job := Job{i, randomno}
        jobs <- job
    }
    close(jobs)
}
func result(done chan bool) {  
    for result := range results {
        fmt.Printf("Job id %d, input random no %d , sum of digits %d\n", result.job.id, result.job.randomno, result.sumofdigits)
    }
    done <- true
}
func main() {  
    startTime := time.Now()
    noOfJobs := 100
    go allocate(noOfJobs)
    done := make(chan bool)
    go result(done)
    noOfWorkers := 10
    createWorkerPool(noOfWorkers)
    <-done
    endTime := time.Now()
    diff := endTime.Sub(startTime)
    fmt.Println("total time taken ", diff.Seconds(), "seconds")
}


Output:

Job id 1, input random no 636 , sum of digits 15
Job id 0, input random no 878 , sum of digits 23
Job id 9, input random no 150 , sum of digits 6
Job id 8, input random no 904 , sum of digits 13
Job id 7, input random no 998 , sum of digits 26
Job id 6, input random no 520 , sum of digits 7
Job id 5, input random no 735 , sum of digits 15
Job id 4, input random no 895 , sum of digits 22
Job id 3, input random no 983 , sum of digits 20
Job id 2, input random no 407 , sum of digits 11
Job id 11, input random no 538 , sum of digits 16
Job id 10, input random no 212 , sum of digits 5
Job id 19, input random no 914 , sum of digits 14
Job id 18, input random no 20 , sum of digits 2
Job id 17, input random no 506 , sum of digits 11
Job id 16, input random no 630 , sum of digits 9
Job id 15, input random no 215 , sum of digits 8
Job id 14, input random no 436 , sum of digits 13
Job id 13, input random no 362 , sum of digits 11
Job id 12, input random no 750 , sum of digits 12
Job id 21, input random no 207 , sum of digits 9
Job id 20, input random no 272 , sum of digits 11
Job id 29, input random no 705 , sum of digits 12
Job id 28, input random no 942 , sum of digits 15
Job id 27, input random no 964 , sum of digits 19
Job id 26, input random no 43 , sum of digits 7
Job id 25, input random no 565 , sum of digits 16
Job id 24, input random no 135 , sum of digits 9
Job id 23, input random no 298 , sum of digits 19
Job id 22, input random no 266 , sum of digits 14
Job id 31, input random no 249 , sum of digits 15
Job id 30, input random no 562 , sum of digits 13
Job id 39, input random no 189 , sum of digits 18
Job id 38, input random no 84 , sum of digits 12
Job id 37, input random no 718 , sum of digits 16
Job id 36, input random no 357 , sum of digits 15
Job id 35, input random no 152 , sum of digits 8
Job id 34, input random no 840 , sum of digits 12
Job id 33, input random no 203 , sum of digits 5
Job id 32, input random no 734 , sum of digits 14
Job id 41, input random no 256 , sum of digits 13
Job id 40, input random no 871 , sum of digits 16
Job id 49, input random no 102 , sum of digits 3
Job id 48, input random no 370 , sum of digits 10
Job id 47, input random no 694 , sum of digits 19
Job id 46, input random no 97 , sum of digits 16
Job id 45, input random no 711 , sum of digits 9
Job id 44, input random no 55 , sum of digits 10
Job id 43, input random no 252 , sum of digits 9
Job id 42, input random no 928 , sum of digits 19
Job id 51, input random no 403 , sum of digits 7
Job id 50, input random no 801 , sum of digits 9
Job id 59, input random no 14 , sum of digits 5
Job id 58, input random no 871 , sum of digits 16
Job id 57, input random no 606 , sum of digits 12
Job id 56, input random no 728 , sum of digits 17
Job id 55, input random no 403 , sum of digits 7
Job id 54, input random no 13 , sum of digits 4
Job id 53, input random no 690 , sum of digits 15
Job id 52, input random no 738 , sum of digits 18
Job id 61, input random no 213 , sum of digits 6
Job id 60, input random no 728 , sum of digits 17
Job id 69, input random no 164 , sum of digits 11
Job id 68, input random no 122 , sum of digits 5
Job id 67, input random no 656 , sum of digits 17
Job id 66, input random no 764 , sum of digits 17
Job id 65, input random no 638 , sum of digits 17
Job id 64, input random no 487 , sum of digits 19
Job id 63, input random no 885 , sum of digits 21
Job id 62, input random no 579 , sum of digits 21
Job id 71, input random no 450 , sum of digits 9
Job id 70, input random no 829 , sum of digits 19
Job id 79, input random no 512 , sum of digits 8
Job id 78, input random no 160 , sum of digits 7
Job id 77, input random no 382 , sum of digits 13
Job id 76, input random no 766 , sum of digits 19
Job id 75, input random no 144 , sum of digits 9
Job id 74, input random no 420 , sum of digits 6
Job id 73, input random no 500 , sum of digits 5
Job id 72, input random no 683 , sum of digits 17
Job id 81, input random no 981 , sum of digits 18
Job id 80, input random no 366 , sum of digits 15
Job id 89, input random no 343 , sum of digits 10
Job id 88, input random no 728 , sum of digits 17
Job id 87, input random no 167 , sum of digits 14
Job id 86, input random no 236 , sum of digits 11
Job id 85, input random no 421 , sum of digits 7
Job id 84, input random no 47 , sum of digits 11
Job id 83, input random no 595 , sum of digits 19
Job id 82, input random no 988 , sum of digits 25
Job id 91, input random no 40 , sum of digits 4
Job id 90, input random no 515 , sum of digits 11
Job id 99, input random no 641 , sum of digits 11
Job id 98, input random no 961 , sum of digits 16
Job id 97, input random no 315 , sum of digits 9
Job id 96, input random no 732 , sum of digits 12
Job id 95, input random no 922 , sum of digits 13
Job id 94, input random no 450 , sum of digits 9
Job id 93, input random no 766 , sum of digits 19
Job id 92, input random no 627 , sum of digits 15
total time taken  20 seconds

Program exited.