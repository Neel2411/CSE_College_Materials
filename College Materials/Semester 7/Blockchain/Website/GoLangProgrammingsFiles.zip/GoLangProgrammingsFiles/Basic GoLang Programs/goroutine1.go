package main

import (
	"fmt"
	"time"
)

func sayHello(){
	fmt.Println(" sayHello from the Function")
}

func main() {
	go sayHello()
	fmt.Println(" Maverick ")
	time.Sleep(1 * time.Second)
	fmt.Println(" Maverick 2 ")
}

Output:

Maverick 
 sayHello from the Function
 Maverick 2 

Program exited.