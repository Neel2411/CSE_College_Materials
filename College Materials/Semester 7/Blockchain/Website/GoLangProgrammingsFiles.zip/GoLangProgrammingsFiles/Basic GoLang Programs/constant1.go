package main


import (
		"fmt"
	//	"math"
		"unsafe"
	)


func main() { 
	
	fmt.Println(" From constant 1:	")
	const a = 5
	fmt.Println(" From constant 1:	 ", a)
	
	
	const astring = "New string"
	//fmt.Println(" From constant ", astring)
	
	fmt.Printf(" Type is %T::: size is %d", astring,unsafe.Sizeof(astring))
	
	//	fmt.Printf(" Type of c is %T, size of c is %d", c , unsafe.Sizeof(c))

}


From constant 1:	
 From constant 1:	  5
 Type is string::: size is 8
Program exited.