package main



//This program is an example of Polymorphism
// Same function name in differnt context/structure
// In this example, FixedBilling, TimeAndMaterial and Advertisement  has same function names: Calculate() and Source()


import (  
    "fmt"
)


//Income is an interface
//This interface has 2 functions namely calcualte() and Source()

type Income interface {  
    calculate() int
    source() string
}

//FixedBilling is a structure

type FixedBilling struct {  
    projectName  string
    biddedAmount int
}


//TimeAndMaterial is a structure


type TimeAndMaterial struct {  
    projectName string
    noOfHours   int
    hourlyRate  int
}


//Advertisement is a structure

type Advertisement struct {  
    adName     string
    CPC        int
    noOfClicks int
}


//Function calculate() returns the int value (biddedAmount)
// In this example, FixedBilling, TimeAndMaterial and Advertisement  has same function names: Calculate() and Source()

func (fb FixedBilling) calculate() int {  
    return fb.biddedAmount
}


//Function source() returns a string value (projectName)

func (fb FixedBilling) source() string {  
    return fb.projectName
}

// In this example, FixedBilling, TimeAndMaterial and Advertisement  has same function names: Calculate() and Source()
//Function calcualte() returns an int value (hourlyRate)

func (tm TimeAndMaterial) calculate() int {  
    return tm.noOfHours * tm.hourlyRate
}

//Function source() returns a string value (projectName)

func (tm TimeAndMaterial) source() string {  
    return tm.projectName
}


// In this example, FixedBilling, TimeAndMaterial and Advertisement  has same function names: Calculate() and Source()
//Function calcualte() returns an int value (noOfClicks)

func (a Advertisement) calculate() int {  
    return a.CPC * a.noOfClicks
}

func (a Advertisement) source() string {  
    return a.adName
}

// calculateNetIncome is a function with argument as array of interface named as Income
//Income Interface has 2 functions namely calcualte() and Source()

func calculateNetIncome(ic []Income) {  
    var netincome int = 0
    for _, income := range ic {

        fmt.Printf("Income From %s = $%d\n", income.source(), income.calculate())
        netincome += income.calculate()
    }
    fmt.Printf("Net income of organisation = $%d", netincome)
}

func main() {  
    project1 := FixedBilling{projectName: "Project 1", biddedAmount: 5000}
    project2 := FixedBilling{projectName: "Project 2", biddedAmount: 10000}
    project3 := TimeAndMaterial{projectName: "Project 3", noOfHours: 160, hourlyRate: 25}


    bannerAd := Advertisement{adName: "Banner Ad", CPC: 2, noOfClicks: 500}
    popupAd := Advertisement{adName: "Popup Ad", CPC: 5, noOfClicks: 750}

//incomeStreams is an array of Income which is an interface

    incomeStreams := []Income{project1, project2, project3, bannerAd, popupAd}

    calculateNetIncome(incomeStreams)
}



Income From Project 1 = $5000
Income From Project 2 = $10000
Income From Project 3 = $4000
Income From Banner Ad = $1000
Income From Popup Ad = $3750
Net income of organisation = $23750
Program exited.