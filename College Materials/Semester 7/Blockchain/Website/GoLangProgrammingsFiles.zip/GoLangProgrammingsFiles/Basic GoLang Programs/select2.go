package main

import (  
    "fmt"
    "time"
)


//Channels are the pipes that connect concurrent goroutines.
//You can send values into channels from one goroutine and receive those values into another goroutine.


func process(ch chan string) {  
    time.Sleep(10500 * time.Millisecond)

//The <-channel syntax receives a value from the channel. 
    ch <- "process successful"
}

func main() {  
    ch := make(chan string)
    go process(ch)
    for {
//sleep for 1000 * time.Millisecond
//for loop will get executed until rturn statement is executed
        time.Sleep(1000 * time.Millisecond)

        select {
        case v := <-ch:
            fmt.Println("received value: ", v)
//This will happen only after 10500 * time.Millisecond
//That means 10 times the default value will be printed 
            return
        default:
            fmt.Println("no value received")
        }
    }

}


Output:

no value received
no value received
no value received
no value received
no value received
no value received
no value received
no value received
no value received
no value received
received value:  process successful