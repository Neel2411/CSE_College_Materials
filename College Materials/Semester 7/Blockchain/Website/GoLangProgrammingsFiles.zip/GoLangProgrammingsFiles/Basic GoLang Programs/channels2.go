package main

import 	(
	"fmt"
	"time"
	)
	
	func sayhello(){
		fmt.Println(" Say Hello - GO ROUTINE ")
	}
	func main() {
		go sayhello()
		time.Sleep(1 * time.Second)
		fmt.Println(" From Main ")
	}


Output:

 Say Hello - GO ROUTINE 
 From Main 

Program exited.