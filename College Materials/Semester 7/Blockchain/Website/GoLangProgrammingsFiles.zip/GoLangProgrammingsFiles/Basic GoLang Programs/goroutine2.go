package main

import (
	"fmt"
	"time"
	//"math"
)


func printNumber() {
	
	for i := 1; i <= 5 ; i++  {

//When this function is sleep it will go and execute other function of go rountine. 

		time.Sleep(250 * time.Millisecond)
		fmt.Printf(" %d", i)
	}

}

func printLetter() {
	
	for i := 'a'; i <= 'e'; i++ {

//When this function is sleep it will go and execute other function of go rountine. 
		time.Sleep(250 * time.Millisecond)
		fmt.Printf(" %c", i)
	}
}

func sayHello(){
	fmt.Println(" sayHello from the Function")
}

func main() {
	go	printNumber()
	go	printLetter()

//If the below statement is removed then nothing will be printed as the main funciton will not wait for the above two statements.
	
	time.Sleep(3000* time.Millisecond)
	
	fmt.Println(" --Exiting Main Program --")
}

Output:

a 1 2 b c 3 4 d e 5 --Exiting Main Program --

Program exited.